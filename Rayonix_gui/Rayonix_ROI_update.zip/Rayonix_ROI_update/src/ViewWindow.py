# python3.8/Qt5
# coding: UTF-8
#from PyQt5.QtCore import *
#from PyQt5.QtGui import *
import subprocess
import logging
import string
import datetime
import traceback
import os.path
import sys
import os, glob, random
import time
import math
import select
import csv
import numpy as np
import pandas as pd
from decimal import *
import threading
import multiprocessing as mp
import dbpy
import FD_config

from PyQt5 import QtCore, QtGui, QtWidgets, uic

import matplotlib.pyplot as plt
from matplotlib.widgets import Cursor
from matplotlib.figure import Figure
from matplotlib.backends.backend_qt5agg import (FigureCanvasQTAgg as FigureCanvas, NavigationToolbar2QT as NavigationToolbar)

import pyqtgraph as pg

# Main_Window class
class ViewWindow(QtWidgets.QMainWindow):

##########################################################################################################	
### 0. ###	
	def __init__(self):
		self.window_name = "Main_Window"
		QtWidgets.QMainWindow.__init__(self)
		Ui_ViewWindow = uic.loadUiType("ui/ViewWindow.ui", self)[0]
		self.ui = Ui_ViewWindow()
		self.ui.setupUi(self)
		
		self.item_position_dictionary = {
			"ViewWindowInside":self.geometry(),
			"Setting":self.ui.group_settings.geometry(),
			"Trend":self.ui.group_Trend.geometry(),
			"Parameter":self.ui.group_Parameter.geometry(),
			}
		
		self.makeImageViewer()
			
		# Set ToolTip			
		
##########################################################################################################	

	def makeImageViewer(self):
		# widget = QWidget()

		imv = pg.ImageView()

		# colors = [
		# 	(0, 0, 0),
		# 	(45, 5, 61),
		# 	(84, 42, 55),
		# 	(150, 87, 60),
		# 	(208, 171, 141),
		# 	(255, 255, 255)
		# ]

		# cmap = pg.ColorMap(pos=np.linspace(0.0, 1.0, 6), color=colors)
		# imv.setColorMap(cmap)

		# layout = QGridLayout()
		# widget.setLayout(layout)
		# layout.addWidget(label, 1, 0)
		# layout.addWidget(imv, 0, 1, 3, 1)
		# value = imv.getRoiPlot()




