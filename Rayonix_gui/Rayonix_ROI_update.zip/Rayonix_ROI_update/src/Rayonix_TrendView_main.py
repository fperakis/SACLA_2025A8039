# python3.8/Qt5
# coding: UTF-8

import subprocess
import logging
import string
import datetime
import math
import traceback
import os.path
import sys
import os, glob, random
import time
import math
import select
import csv
import numpy as np
import pandas as pd
from decimal import *
import threading
import multiprocessing as mp
import dbpy
import signal
import glob
from natsort import natsorted
import FD_config

from PyQt5 import QtCore, QtGui, QtWidgets, uic

import matplotlib.pyplot as plt
from matplotlib.widgets import Cursor
from matplotlib.figure import Figure
from matplotlib.backends.backend_qt5agg import (FigureCanvasQTAgg as FigureCanvas, NavigationToolbar2QT as NavigationToolbar)

import ViewWindow
import ViewControl

# keyboard interrupt
def keyboard_interrupt(*args):
	sys.stderr.write('\r')
	if FD_config.window_view is not None:
		FD_config.window_view.close()
	sys.exit(1)
        
if __name__=="__main__":
	app = QtWidgets.QApplication(sys.argv)
        
	FD_config.window_view = ViewWindow.ViewWindow()
	FD_config.window_view.show()
    
	MinClass = ViewControl.ViewControl("Main")
    
	#for keyboard interrupt
	signal.signal(signal.SIGINT, keyboard_interrupt)
	timer = QtCore.QTimer()
	timer.start(1000)
	timer.timeout.connect(lambda: None)
    
	app.exec_()
    
	sys.exit()
