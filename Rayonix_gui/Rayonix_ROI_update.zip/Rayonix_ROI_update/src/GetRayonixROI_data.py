#python3.5
# coding: UTF-8

import subprocess
import logging
import string
import datetime
import math
import traceback
import os.path
import sys
import os, glob, random
import time
import math
import select
import csv
import numpy as np
import pandas as pd
from decimal import *
import threading
import dbpy
import signal
import glob
from natsort import natsorted
import FD_config
from PIL import Image

import matplotlib.pyplot as plt
from matplotlib.widgets import Cursor
from matplotlib.figure import Figure
from matplotlib.backends.backend_qt5agg import (FigureCanvasQTAgg as FigureCanvas, NavigationToolbar2QT as NavigationToolbar)

class GetRayonixData:

##########################################################################################################	
### 0. ###	
	def __init__(self,parent):
		self.parent = parent
		self.name = ""			

##########################################################################################################
### 1.get single Rayonix integrated intensity with ROI ###
	def GetRayonixDataSingle(self, img_path, X1, X2, Y1, Y2):
		try:
			img = np.array(Image.open(img_path))
			ret = np.sum(img[X1:X2+1,Y1:Y2+1])
		except Exception as ex:	
			return np.nan
		else:
			return ret

##########################################################################################################
### 2.get list Rayonix integrated intensity with ROI ###
	def GetRayonixDataArray(self, img_pathlist, X1, X2, Y1, Y2):
		try:
			for i in range(len(img_pathlist)):
				img_path = img_pathlist[i]
				count = self.GetRayonixDataSingle(img_path, int(X1), int(X2), int(Y1), int(Y2))
				if i == 0:
					ret = np.array([count])
				else :
					ret = np.concatenate([ret,np.array([count])],axis=0)
		except Exception as ex:	
			return np.zeros(len(img_pathlist)) * np.nan
		else:
			return ret

##########################################################################################################
##########################################################################################################
##########################################################################################################
