# python3.8/Qt5
# coding: UTF-8

import subprocess
import logging
import string
import datetime
import math
import traceback
import os.path
import sys
import os, glob, random
import time
import math
import select
import csv
import numpy as np
import pandas as pd
from decimal import *
import threading
import multiprocessing as mp
import dbpy
import signal
import glob
from natsort import natsorted
import FD_config

from PyQt5 import QtCore, QtGui, QtWidgets, uic
from GetRayonixROI_data import GetRayonixData

import matplotlib.pyplot as plt
import matplotlib.dates as mdates
from matplotlib.widgets import Cursor
from matplotlib.figure import Figure
from matplotlib.backends.backend_qt5agg import (FigureCanvasQTAgg as FigureCanvas, NavigationToolbar2QT as NavigationToolbar)

## View control class
class ViewControl(QtWidgets.QWidget):

##########################################################################################################
### Rayonix data path update ###
		def update_Rayonix_data_path(self):
			try:				
				self.Rayonix_path = FD_config.window_view.ui.input_Rayonix_data_path.text()	
			except Exception as ex:
				self.error_msg = "[error] : Rayonix data path input : " + str(ex)
				self.Log_file_append_msg(self.error_msg)
				FD_config.window_view.ui.input_log.appendPlainText(self.error_msg)	
				return -1
			return 0
##########################################################################################################

##########################################################################################################
### Shotnumber update ###
		def update_shotnumber(self):
			try:				
				self.shotnumber = int(FD_config.window_view.ui.input_shotnumber.value())	
			except Exception as ex:
				self.error_msg = "[error] : shotnumber input : " + str(ex)
				self.Log_file_append_msg(self.error_msg)
				FD_config.window_view.ui.input_log.appendPlainText(self.error_msg)	
				return -1
			return 0
##########################################################################################################

##########################################################################################################
### ROI X1 update ###
		def update_roi_X1(self):
			try:				
				self.roi_X1 = int(FD_config.window_view.ui.input_X1.value())	
			except Exception as ex:
				self.error_msg = "[error] : X1 input : " + str(ex)
				self.Log_file_append_msg(self.error_msg)
				FD_config.window_view.ui.input_log.appendPlainText(self.error_msg)	
				return -1
			return 0
##########################################################################################################

##########################################################################################################
### ROI X2 update ###
		def update_roi_X2(self):
			try:				
				self.roi_X2 = int(FD_config.window_view.ui.input_X2.value())	
			except Exception as ex:
				self.error_msg = "[error] : X2 input : " + str(ex)
				self.Log_file_append_msg(self.error_msg)
				FD_config.window_view.ui.input_log.appendPlainText(self.error_msg)	
				return -1
			return 0
##########################################################################################################

##########################################################################################################
### ROI Y1 update ###
		def update_roi_Y1(self):
			try:				
				self.roi_Y1 = int(FD_config.window_view.ui.input_Y1.value())	
			except Exception as ex:
				self.error_msg = "[error] : Y1 input : " + str(ex)
				self.Log_file_append_msg(self.error_msg)
				FD_config.window_view.ui.input_log.appendPlainText(self.error_msg)	
				return -1
			return 0
##########################################################################################################

##########################################################################################################
### ROI Y2 update ###
		def update_roi_Y2(self):
			try:				
				self.roi_Y2 = int(FD_config.window_view.ui.input_Y2.value())	
			except Exception as ex:
				self.error_msg = "[error] : Y2 input : " + str(ex)
				self.Log_file_append_msg(self.error_msg)
				FD_config.window_view.ui.input_log.appendPlainText(self.error_msg)	
				return -1
			return 0
##########################################################################################################

##########################################################################################################
### Threshold update ###
		def update_threshold(self):
			try:				
				self.threshold = int(FD_config.window_view.ui.input_Threshold.value())	
			except Exception as ex:
				self.error_msg = "[error] : threshold input : " + str(ex)
				self.Log_file_append_msg(self.error_msg)
				FD_config.window_view.ui.input_log.appendPlainText(self.error_msg)	
				return -1
			return 0
##########################################################################################################

##########################################################################################################
### Range Ymin update ###
		def update_range_Ymin(self):
			try:				
				self.range_Ymin = int(FD_config.window_view.ui.input_Yrange_min.value())	
			except Exception as ex:
				self.error_msg = "[error] : Ymin input : " + str(ex)
				self.Log_file_append_msg(self.error_msg)
				FD_config.window_view.ui.input_log.appendPlainText(self.error_msg)	
				return -1
			return 0
##########################################################################################################

##########################################################################################################
### Range Ymax update ###
		def update_range_Ymax(self):
			try:				
				self.range_Ymax = int(FD_config.window_view.ui.input_Yrange_max.value())	
			except Exception as ex:
				self.error_msg = "[error] : Ymax input : " + str(ex)
				self.Log_file_append_msg(self.error_msg)
				FD_config.window_view.ui.input_log.appendPlainText(self.error_msg)	
				return -1
			return 0
##########################################################################################################

##########################################################################################################
### Auto range update ###
		def update_auto_range(self):
			try:
				if FD_config.window_view.ui.checkBox.isChecked() == True:		
					self.auto_range = True
				else :
					self.auto_range = False
			except Exception as ex:
				self.error_msg = "[error] : auto range checkbox : " + str(ex)
				self.Log_file_append_msg(self.error_msg)
				FD_config.window_view.ui.input_log.appendPlainText(self.error_msg)	
				return -1
			return 0
##########################################################################################################

##########################################################################################################
### Log file create/re-creation ###
		def Log_file_create(self):
			try:
				if (os.path.exists(self.Log_path) == False):
					### create new file ###
					self.f = open(self.Log_path, "w")
					### time input ###
					self.f.write(str((self.log_datetime).year)+"/"+str((self.log_datetime).month)+"/"+str((self.log_datetime).day)+",\t"+str((self.log_datetime).hour)+":"+str((self.log_datetime).minute)+":"+str((self.log_datetime).second)+"\r\n")
					self.f.close()
					FD_config.window_view.ui.log_filepath.setStyleSheet("background-color:rgb(225, 225, 225); font-size:8pt; font-weight:normal;")
					FD_config.window_view.ui.log_filepath.setText(self.Log_path)
			except Exception as ex:
				self.error_msg = "[error] : Log file creation"
				FD_config.window_view.ui.input_log.appendPlainText(self.error_msg)	
				return -1
			return 0			
##########################################################################################################

##########################################################################################################
### Log file append ###
		def Log_file_append_msg(self, msg):
			if (os.path.isfile(self.Log_path) == True):
				try:
					self.f = open(self.Log_path, "a")
					self.log_append_datetime = datetime.datetime.now()
					msg_input = msg + "\t:\t"+str((self.log_append_datetime).year)+"/"+str((self.log_append_datetime).month)+"/"+str((self.log_append_datetime).day)+",\t"+str((self.log_append_datetime).hour)+":"+str((self.log_append_datetime).minute)+":"+str((self.log_append_datetime).second)
					self.f.write(msg_input)
					self.f.write("\r\n")
					self.f.close()
				except Exception as ex:
					self.error_msg = "[error] : Log file append"
					FD_config.window_view.ui.input_log.appendPlainText(self.error_msg)	
			else:
				self.Log_file_create()
				try:
					self.f = open(self.Log_path, "a")
					msg_input = msg + "\t:\t"+str((self.log_append_datetime).year)+"/"+str((self.log_append_datetime).month)+"/"+str((self.log_append_datetime).day)+",\t"+str((self.log_append_datetime).hour)+":"+str((self.log_append_datetime).minute)+":"+str((self.log_append_datetime).second)
					self.f.write(msg_input)
					self.f.write("\r\n")
					self.f.close()
				except Exception as ex:
					self.error_msg = "[error] : Log file append"
					FD_config.window_view.ui.input_log.appendPlainText(self.error_msg)
			return			
##########################################################################################################

##########################################################################################################
### Update BL number ###
		def update_BL(self):
			try:
				self.BL_number = FD_config.window_view.ui.select_BL.currentText()
			except Exception as ex:
				self.error_msg = "[error] : BL number input : "  + str(ex)
				self.Log_file_append_msg(self.error_msg)
				FD_config.window_view.ui.input_log.appendPlainText(self.error_msg)	
				return -1
			return 0			
##########################################################################################################

##########################################################################################################
### Initialize BL list ###
		def initialize_BL_list(self):
			try:
				FD_config.window_view.ui.select_BL.clear()
				FD_config.window_view.ui.select_BL.addItem("3")
				FD_config.window_view.ui.select_BL.addItem("2")
				FD_config.window_view.ui.select_BL.addItem("1")
				FD_config.window_view.ui.select_BL.setCurrentIndex(0)
				self.BL_number = "3"
			except Exception as ex:
				self.error_msg = "[error] : Initialioze BL list : " + str(ex)
				self.Log_file_append_msg(self.error_msg)
				FD_config.window_view.ui.input_log.appendPlainText(self.error_msg)
				self.BL_number = "3"	
				return -1
			return 0	
##########################################################################################################

##########################################################################################################
### Check Rayonix data path input ###
		def check_Rayonix_data_path_input(self):
			try:
				ret = os.path.isdir(self.Rayonix_path)	
				if not ret:
					self.error_msg = "[error] : check Rayonix data path : not found"
					self.Log_file_append_msg(self.error_msg)
					FD_config.window_view.ui.input_log.appendPlainText(self.error_msg)	
					return -1
				else:
					self.log_msg = "Rayonix data path search : success"
					self.Log_file_append_msg(self.log_msg)
					FD_config.window_view.ui.input_log.appendPlainText(self.log_msg)				
			except Exception as ex:
				self.error_msg = "[error] : check Rayonix data path : " + str(ex)
				self.Log_file_append_msg(self.error_msg)
				FD_config.window_view.ui.input_log.appendPlainText(self.error_msg)	
				return -1
			return 0
##########################################################################################################

##########################################################################################################
### Check Rayonix data hidden file ###
		def check_Rayonix_data_path_hidden_file(self):
			try:
				if self.Rayonix_path[-1] == '/':
					ret = glob.glob(self.Rayonix_path+'.*')
				else :
					ret = glob.glob(self.Rayonix_path+'/.*')
				if (len(ret) > 0):
					self.hidden = True
				else:
					self.hidden = False
					self.error_msg = "[error] : check Rayonix data path hidden status file"
					self.Log_file_append_msg(self.error_msg)
					FD_config.window_view.ui.input_log.appendPlainText(self.error_msg)	
					return -1
			except Exception as ex:
				self.hidden = False
				self.error_msg = "[error] : check Rayonix data path hidden status file : " + str(ex)
				self.Log_file_append_msg(self.error_msg)
				FD_config.window_view.ui.input_log.appendPlainText(self.error_msg)	
				return -1
			return 0
##########################################################################################################

##########################################################################################################
### Parameter disable ###
		def disable_parameter(self):
			FD_config.window_view.ui.input_Rayonix_data_path.setDisabled(True)
			return 0
##########################################################################################################

##########################################################################################################
### Parameter enable ###
		def enable_parameter(self):
			FD_config.window_view.ui.input_Rayonix_data_path.setEnabled(True)
			return 0
##########################################################################################################

##########################################################################################################
### Switch Input/Edit ###
		def switch_input_edit(self):
			try:
				if (self.status_indicator == "input"):
					### check Rayonix data path and hidden file ###
					ret_1 = self.check_Rayonix_data_path_input()
					if (ret_1 == -1):
						FD_config.window_view.ui.checkBox_Rayonix_data_path.setChecked(False)
						FD_config.window_view.ui.checkBox_hidden_file.setChecked(False)
						return -1
					else :	
						ret_2 = self.check_Rayonix_data_path_hidden_file()
						if (ret_2 == -1):
							FD_config.window_view.ui.checkBox_Rayonix_data_path.setChecked(True)
							FD_config.window_view.ui.checkBox_hidden_file.setChecked(False)
							return -1
						else:
							FD_config.window_view.ui.checkBox_Rayonix_data_path.setChecked(True)
							FD_config.window_view.ui.checkBox_hidden_file.setChecked(True)
							### change from input to edit mode ###
							self.status_indicator = "edit"
							FD_config.window_view.ui.btn_setting_input_edit.setStyleSheet("background-color:rgb(192, 0, 64); color:rgb(255, 255, 255); font-size:11pt; font-weight:bold;")
							FD_config.window_view.ui.btn_setting_input_edit.setText("Edit")
							self.disable_parameter()
							FD_config.window_view.ui.Rayonix_trendviewer_on_off.setStyleSheet("background-color: rgb(0, 192, 64); color: rgb(255, 255, 255); font-size: 11pt; font-weight:bold;")
							FD_config.window_view.ui.Rayonix_trendviewer_on_off.setEnabled(True)

				else:
					self.status_indicator = "input"
					FD_config.window_view.ui.btn_setting_input_edit.setStyleSheet("background-color:rgb(0, 192, 64); color:rgb(255, 255, 255); font-size:11pt; font-weight:bold;")
					FD_config.window_view.ui.btn_setting_input_edit.setText("Input")
					self.enable_parameter()
					FD_config.window_view.ui.Rayonix_trendviewer_on_off.setStyleSheet("background-color: silver; color: white; font-size: 11pt; font-weight:bold;")
					FD_config.window_view.ui.Rayonix_trendviewer_on_off.setDisabled(True)
					FD_config.window_view.ui.checkBox_Rayonix_data_path.setChecked(False)
					FD_config.window_view.ui.checkBox_hidden_file.setChecked(False)
			except Exception as ex:
				self.error_msg = "[error] : input_edit process : " + str(ex)
				self.Log_file_append_msg(self.error_msg)
				FD_config.window_view.ui.input_log.appendPlainText(self.error_msg)	
				return -1
			return 0
##########################################################################################################			

##########################################################################################################
### Switch TrendView ###
		def switch_trendview(self):
			try:
				if (self.status_indicator == "input"):
					self.error_msg = "[error] : trendview process : not ready to start because of input mode"
					self.Log_file_append_msg(self.error_msg)
					FD_config.window_view.ui.input_log.appendPlainText(self.error_msg)	
					return -1
				if (self.trendview_indicator == 1):
					self.trendview_multiprocessing_stop()
					self.stop_countdown()
					self.reset_countdown()
					self.stop_trendview_initialization()
				elif (self.trendview_indicator == 0):
					self.start_trendview_initialization()
					self.start_countdown()
					self.trendview_multiprocessing_start()
			except Exception as ex:
				self.error_msg = "[error] : trendview process : " + str(ex)
				self.Log_file_append_msg(self.error_msg)
				FD_config.window_view.ui.input_log.appendPlainText(self.error_msg)	
				return -1
			return 0
##########################################################################################################

##########################################################################################################
### Stop TrendView ###
		def stop_trendview_initialization(self):
			try:
				FD_config.window_view.ui.Rayonix_trendviewer_on_off.setStyleSheet("background-color: silver; color: white; font-size: 11pt; font-weight:bold;")
				FD_config.window_view.ui.Rayonix_trendviewer_on_off.setText("Trend View On")
				FD_config.window_view.ui.Rayonix_trendviewer_on_off.setDisabled(True)
				FD_config.window_view.ui.btn_setting_input_edit.setStyleSheet("background-color:rgb(0, 192, 64); color:rgb(255, 255, 255); font-size:11pt; font-weight:bold;")
				FD_config.window_view.ui.btn_setting_input_edit.setText("Input")
				FD_config.window_view.ui.btn_setting_input_edit.setEnabled(True)
				self.enable_parameter()
				self.status_indicator = "input"
				self.trendview_indicator = 0
				FD_config.window_view.ui.checkBox_Rayonix_data_path.setChecked(False)
				FD_config.window_view.ui.checkBox_hidden_file.setChecked(False)
			except Exception as ex:
				self.error_msg = "[error] : trendview stop process : " + str(ex)
				self.Log_file_append_msg(self.error_msg)
				FD_config.window_view.ui.input_log.appendPlainText(self.error_msg)	
				return -1
			return 0
##########################################################################################################

##########################################################################################################
### Start Trendview ###
		def start_trendview_initialization(self):
			try:
				FD_config.window_view.ui.btn_setting_input_edit.setStyleSheet("background-color: silver; color: white; font-size: 11pt; font-weight:bold;")
				FD_config.window_view.ui.btn_setting_input_edit.setText("Fix")
				FD_config.window_view.ui.btn_setting_input_edit.setDisabled(True)
				FD_config.window_view.ui.Rayonix_trendviewer_on_off.setStyleSheet("background-color:rgb(0, 64, 192); color:rgb(255, 255, 255); font-size:11pt; font-weight:bold;")
				FD_config.window_view.ui.Rayonix_trendviewer_on_off.setText("Trend View Off")
				self.trendview_indicator = 1
			except Exception as ex:
				self.error_msg = "[error] : trendview start process : " + str(ex)
				self.Log_file_append_msg(self.error_msg)
				FD_config.window_view.ui.input_log.appendPlainText(self.error_msg)	
				return -1
			return 0
##########################################################################################################

##########################################################################################################
### Trend View multiprocessing ###			
		def trendview_multiprocessing_start(self):	
			### case trendview thread is running already ###
			self.TrendView.setup()
			self.TrendView.start()	
			self.log_msg = "[Trend View] : multiprocessing start"
			self.Log_file_append_msg(self.log_msg)
			FD_config.window_view.ui.input_log.appendPlainText(self.log_msg)	
##########################################################################################################

##########################################################################################################
### Trend View multiprocessing stop ###			
		def trendview_multiprocessing_stop(self):
			self.TrendView.stop()
			self.TrendView.wait()
			self.log_msg = "[Trend View] : multiprocessing stop"
			self.Log_file_append_msg(self.log_msg)
			FD_config.window_view.ui.input_log.appendPlainText(self.log_msg)			
##########################################################################################################	

##########################################################################################################	
### Display message log window ###
		def log_output(self,msg):
			FD_config.window_view.ui.input_log.appendPlainText(msg)
##########################################################################################################

##########################################################################################################	
### Display message log window ###
		def finish_process_Qthread(self):
			self.TrendView.wait()
			self.log_msg = "[Trend View] : multiprocessing finish"
			self.Log_file_append_msg(self.log_msg)
			FD_config.window_view.ui.input_log.appendPlainText(self.log_msg)	
##########################################################################################################

##########################################################################################################
### Onetime update graph ###
		def onetime_graph_update(self):
			self.update_graph()
			return 0
##########################################################################################################

##########################################################################################################
### Timer count for repeated update of position and limit ###
		def start_countdown(self):
			self.timer = QtCore.QTimer()
			self.timer.setInterval(1500)
			self.timecount = 1500
			self.timer.start(self.timecount)
			self.timer.timeout.connect(self.onetime_graph_update)
		
		def stop_countdown(self):
			self.timer.stop()
		
		def reset_countdown(self):
			self.timer.stop()
			self.timecount = 1500
				
##########################################################################################################

##########################################################################################################
### Update graph for Rayonix ROI counts ###
		def update_graph(self):
			try:
				### update data to output in graph ###
				Linux_time = datetime.datetime.now()
				self.graph_Rayonix_data = self.TrendView.data_array
				self.graph_time_x = self.TrendView.time_list
				### update hit rate ###
				self.hit_rate = len(self.graph_Rayonix_data[self.graph_Rayonix_data > self.threshold]) / len(self.graph_Rayonix_data) * 100.0
				### vertical range ###
				y_range = np.nanmax(self.graph_Rayonix_data) - np.nanmin(self.graph_Rayonix_data)
				if y_range == 0:
					y_range = 1
				### pandas dataframe ###
				df = pd.DataFrame({'time':pd.to_datetime(self.graph_time_x),'integrated count':self.graph_Rayonix_data})
				### add np.nan current data ###
				add_df = pd.DataFrame({'time':[df.iloc[-1,0]+pd.DateOffset(hours=0.05)],'integrated count':[np.nan]})
				add_df = pd.DataFrame({'time':[Linux_time],'integrated count':[np.nan]})
				#df = pd.concat([df,add_df], axis=0)
				### create threshold line ###
				threshold_X = np.array([df.iloc[0,0],df.iloc[-1,0]])
				threshold_Y = np.array([self.threshold, self.threshold])
				### graph update ###
				self.TrendView_canvas.axes.clear()	
				self.TrendView_canvas.axes.plot(df['time'], df['integrated count'], 'b-', linewidth=0.1, linestyle='-', markersize=1.0, marker='o')
				self.TrendView_canvas.axes.plot(threshold_X, threshold_Y, 'r--', linewidth=0.1, linestyle='-', markersize=0.0, marker='o')
				### graph condition ###
				self.TrendView_canvas.axes.xaxis.set_major_formatter(mdates.DateFormatter("%H:%M:%S"))
				self.TrendView_canvas.axes.set_xticks([df.iloc[0,0],df.iloc[0,0]+(df.iloc[-1,0]-df.iloc[0,0])/3,df.iloc[0,0]+(df.iloc[-1,0]-df.iloc[0,0])/3*2,df.iloc[-1,0]])
				### graph y range setting ###
				if self.auto_range == True:
					y_axis_min = np.nanmin(self.graph_Rayonix_data)-y_range*0.1
					y_axis_max = np.nanmax(self.graph_Rayonix_data)+y_range*0.1
					y_axis_range = y_axis_max - y_axis_min
					self.TrendView_canvas.axes.set_ylim(y_axis_min, y_axis_max)
					self.TrendView_canvas.axes.set_yticks([y_axis_min,y_axis_min+y_axis_range/4,y_axis_min+y_axis_range*2/4,y_axis_min+y_axis_range*3/4,y_axis_min+y_axis_range*4/4])
				else :
					if self.range_Ymax > self.range_Ymin:
						self.TrendView_canvas.axes.set_ylim(self.range_Ymin, self.range_Ymax)
					elif self.range_Ymax < self.range_Ymin:
						self.TrendView_canvas.axes.set_ylim(self.range_Ymax, self.range_Ymin)
					else :
						self.TrendView_canvas.axes.set_ylim(self.range_Ymin, self.range_Ymin + 1)
				self.TrendView_canvas.axes.tick_params(axis="both", labelsize=9)
				### draw ###
				self.TrendView_canvas.draw()
				### update###
				FD_config.window_view.ui.status_HitRate.setValue(self.hit_rate)
				FD_config.window_view.ui.status_Runnumber.setText(str(int(self.TrendView.run_list[-1])))
			except Exception as ex:
				self.error_msg = "[error] : onetime graph update : " + str(ex)
				self.Log_file_append_msg(self.error_msg)
				FD_config.window_view.ui.input_log.appendPlainText(self.error_msg)	
				return -1
			return 0
##########################################################################################################

##########################################################################################################
##########################################################################################################
##########################################################################################################
##########################################################################################################	    

##########################################################################################################
##########################################################################################################
##########################################################################################################
##########################################################################################################	       
		def __init__(self, parent):
			self.window_name = "ViewControl"
			self.parent = parent			
			super(ViewControl, self).__init__()			
			### Rayonix path parameter initialization ###
			self.Rayonix_path = ""
			self.shotnumber = 100
			self.initialize_BL_list()
			self.BL_number = "3"
			self.threshold = 100
			self.hidden = False
			### Rayonix img path list and time list initialization ###
			self.latest_run_path = ""
			### Rayonix ROI count graph list ###
			self.graph_Rayonix_data = []
			self.graph_time = []
			self.graph_time_x = []
			self.auto_range = False
			self.range_Ymin = 0
			self.range_Ymax = 1
			self.hit_rate = 0.0
			###  Figure Window ###
			self.TrendView_canvas = TrendView_canvas()
			FD_config.window_view.ui.ROI_count_profile.addWidget(self.TrendView_canvas)
			### FD_config/Log initialization ###
			self.error_msg = ""
			self.warning_msg = ""
			self.directory = os.getcwd()
			self.log_datetime = datetime.datetime.now()
			self.Log_path = (self.directory).replace("src","Log/log_"+str((self.log_datetime).year)+"_"+str((self.log_datetime).month)+"_"+str((self.log_datetime).day)+"_"+str((self.log_datetime).hour)+"_"+str((self.log_datetime).minute)+"_"+str((self.log_datetime).second))
			self.Log_file_create()
			self.log_document = FD_config.window_view.ui.input_log.document
			self.highlighter = Highlighter(self.log_document())
			### Initialize color of "Rayonix Trend Viewer On/Off" before input of parameter ###
			FD_config.window_view.ui.Rayonix_trendviewer_on_off.setStyleSheet("background-color: silver; color: white; font-size: 11pt; font-weight:bold;")
			FD_config.window_view.ui.Rayonix_trendviewer_on_off.setDisabled(True)
			### input/edit indicator initialization ###
			self.status_indicator = "input"
			### trendview indicator initialization ###
			self.trendview_indicator = 0
			### trendview thread ###
			self.TrendView = Rayonix_Trend_View_process()
			self.TrendView.log_trendview_thread_msg.connect(self.log_output)
			self.TrendView.finished.connect(self.finish_process_Qthread)
			##########################################################################################################
			##########################################################################################################
			##########################################################################################################
			### Action ###
			### Parameters input ###
			FD_config.window_view.ui.input_Rayonix_data_path.textChanged.connect(self.update_Rayonix_data_path)
			FD_config.window_view.ui.input_shotnumber.valueChanged.connect(self.update_shotnumber)
			FD_config.window_view.ui.input_X1.valueChanged.connect(self.update_roi_X1)
			FD_config.window_view.ui.input_X2.valueChanged.connect(self.update_roi_X2)
			FD_config.window_view.ui.input_Y1.valueChanged.connect(self.update_roi_Y1)
			FD_config.window_view.ui.input_Y2.valueChanged.connect(self.update_roi_Y2)
			FD_config.window_view.ui.input_Threshold.valueChanged.connect(self.update_threshold)
			FD_config.window_view.ui.input_Yrange_min.valueChanged.connect(self.update_range_Ymin)
			FD_config.window_view.ui.input_Yrange_max.valueChanged.connect(self.update_range_Ymax)
			FD_config.window_view.ui.checkBox.clicked.connect(self.update_auto_range)
			### BL selection input ###
			FD_config.window_view.ui.select_BL.activated.connect(self.update_BL)
			### Parameter input/edit switch ###
			FD_config.window_view.ui.btn_setting_input_edit.clicked.connect(self.switch_input_edit)
			### Trend View on/off switch ###
			FD_config.window_view.ui.Rayonix_trendviewer_on_off.clicked.connect(self.switch_trendview)
			##########################################################################################################
			##########################################################################################################
			##########################################################################################################
			
##########################################################################################################
##########################################################################################################
##########################################################################################################
##########################################################################################################	    

##########################################################################################################
##########################################################################################################
##########################################################################################################
class Rayonix_Trend_View_process(QtCore.QThread):
##########################################################################################################
##########################################################################################################
##########################################################################################################
		log_trendview_thread_msg = QtCore.pyqtSignal(str)

##########################################################################################################	
### trendview_on ###
		def run(self):
			try:
				while (self.stopped == False):
					if (self.stopped == True):
						return
					### create img path list and time array ###
					self.update_setup()
					self.create_Rayonix_data_path_list()
					### get Rayonix data ###
					self.data_array = self.__get_rayonix_data.GetRayonixDataArray(self.img_list, self.roi_X1, self.roi_X2, self.roi_Y1, self.roi_Y2)
					if (np.sum(np.isnan(self.data_array)) == len(self.data_array)):
						self.error_thread_msg = "[error] : All Rayonix data is np.nan (Not a Number)"
						self.Log_file_thread_append_msg(self.error_thread_msg)
						self.log_trendview_thread_msg.emit(self.error_thread_msg)
						continue
					if (self.stopped == True):
						return
			except Exception as ex:
				self.error_thread_msg = "[error] : get Rayonix data from image path list : " + str(ex)
				self.Log_file_thread_append_msg(self.error_thread_msg)
				self.log_trendview_thread_msg.emit(self.error_thread_msg)	
				self.stopped = True
				return
			self.stopped = True
			return	
##########################################################################################################

##########################################################################################################
### Log file append in thread ###
		def Log_file_thread_append_msg(self, msg):
			if (os.path.isfile(self.Log_path) == True):
				try:
					self.f = open(self.Log_path, "a")
					self.log_thread_append_datetime = datetime.datetime.now()
					msg_input = msg + "\t:\t"+str((self.log_thread_append_datetime).year)+"/"+str((self.log_thread_append_datetime).month)+"/"+str((self.log_thread_append_datetime).day)+",\t"+str((self.log_thread_append_datetime).hour)+":"+str((self.log_thread_append_datetime).minute)+":"+str((self.log_thread_append_datetime).second)
					self.f.write(msg_input)
					self.f.write("\r\n")
					self.f.close()
				except Exception as ex:
					self.error_thread_msg = "[error] : Log file append in threading"
					self.log_trendview_thread_msg.emit(self.error_thread_msg)	
			else:
				self.error_thread_msg = "[error] : Log file not found in threading"
				self.log_trendview_thread_msg.emit(self.error_thread_msg)
			return			
##########################################################################################################

##########################################################################################################
### create Rayonix data path list ###
		def create_Rayonix_data_path_list(self):
			try:				
				if self.Rayonix_path[-1] == '/':
					hidden_path = glob.glob(self.Rayonix_path+'.*')[0]
				else :
					hidden_path = glob.glob(self.Rayonix_path+'/.*')[0]
				with open(hidden_path,'r') as f:
					info = f.readlines()
				if len(info) > 0:
					self.latest_run_path = os.path.dirname(info[0].rstrip())
					self.img_list = natsorted(glob.glob(self.latest_run_path+'/*.img'))
					self.run_list = [int(os.path.basename(self.latest_run_path))] * len(self.img_list)
					# get epoch time of hidden file
					epoch_time = os.path.getmtime(hidden_path)
					self.time_array = np.arange(0, 1 / self.rep * (len(self.img_list)), 1 / self.rep) + epoch_time
					###### look for another run to get matching between shotnumber and img number ######
					if len(self.img_list) == self.shotnumber:
						self.time_list = pd.to_datetime(self.time_array, unit = 's')
						return 0
					elif len(self.img_list) > self.shotnumber:
						self.img_list = self.img_list[len(self.img_list)-self.shotnumber:]
						self.run_list = self.run_list[len(self.run_list)-self.shotnumber:]
						self.time_array = self.time_array[len(self.time_array)-self.shotnumber:]
						self.time_list = pd.to_datetime(self.time_array, unit = 's')
						return 0
					elif len(self.img_list) < self.shotnumber:
						ref_run = int(os.path.basename(self.latest_run_path))
						ref_dir = os.path.dirname(self.latest_run_path)
						while len(self.img_list) < self.shotnumber:
							pre_run = ref_run - 1
							if os.path.isdir(ref_dir+'/'+str(pre_run)):
								add_img_list = natsorted(glob.glob(ref_dir+'/'+str(pre_run)+'/*.img'))
								add_run_list = [pre_run] * len(add_img_list)
								self.img_list = add_img_list + self.img_list
								self.run_list = add_run_list + self.run_list
								# get epoch time of hidden file
								add_epoch_time = dbpy.read_starttime(int(self.BL_number),int(pre_run))
								add_time_array = np.arange(0, 1 / self.rep * (len(add_img_list)), 1 / self.rep) + add_epoch_time
								self.time_array = np.concatenate([add_time_array, self.time_array],axis=0)
								if len(self.img_list) >= self.shotnumber:
									self.img_list = self.img_list[len(self.img_list)-self.shotnumber:]
									self.run_list = self.run_list[len(self.run_list)-self.shotnumber:]
									self.time_array = self.time_array[len(self.time_array)-self.shotnumber:]
									self.time_list = pd.to_datetime(self.time_array, unit = 's')
									return 0
								ref_run = pre_run
							else :
								self.time_list = pd.to_datetime(self.time_array, unit = 's')
								self.warning_msg = "[warning] : Number of Rayonix data is less than shotnumber you input"
								self.Log_file_thread_append_msg(self.warning_msg)
								FD_config.window_view.ui.input_log.appendPlainText(self.warning_msg)
								return -1
				else :
					self.latest_run_path = ""
					self.img_list = []
					self.run_list = []
					self.time_list = []
					self.time_array = np.array([])
					self.error_msg = "[error] : read hidden status in Rayonix data path"
					self.Log_file_thread_append_msg(self.error_msg)
					FD_config.window_view.ui.input_log.appendPlainText(self.error_msg)
					return -1
			except Exception as ex:
				self.error_msg = "[error] : read hidden status in Rayonix data path : " + str(ex)
				self.Log_file_thread_append_msg(self.error_msg)
				FD_config.window_view.ui.input_log.appendPlainText(self.error_msg)	
				return -1
			return 0
##########################################################################################################

##########################################################################################################	       
		def setup(self):
			self.stopped = False
			self.Rayonix_path = FD_config.window_view.ui.input_Rayonix_data_path.text()
			self.BL_number = FD_config.window_view.ui.select_BL.currentText()
			self.shotnumber = int(FD_config.window_view.ui.input_shotnumber.value())
			self.roi_X1 = int(FD_config.window_view.ui.input_X1.value())
			self.roi_X2 = int(FD_config.window_view.ui.input_X2.value())
			self.roi_Y1 = int(FD_config.window_view.ui.input_Y1.value())
			self.roi_Y2 = int(FD_config.window_view.ui.input_Y2.value())
			self.range_Ymin = int(FD_config.window_view.ui.input_Yrange_min.value())
			self.range_Ymax = int(FD_config.window_view.ui.input_Yrange_max.value())
			self.Log_path = FD_config.window_view.ui.log_filepath.text()
##########################################################################################################

##########################################################################################################	       
		def update_setup(self):
			self.Rayonix_path = FD_config.window_view.ui.input_Rayonix_data_path.text()
			self.BL_number = FD_config.window_view.ui.select_BL.currentText()
			self.shotnumber = int(FD_config.window_view.ui.input_shotnumber.value())
			self.roi_X1 = int(FD_config.window_view.ui.input_X1.value())
			self.roi_X2 = int(FD_config.window_view.ui.input_X2.value())
			self.roi_Y1 = int(FD_config.window_view.ui.input_Y1.value())
			self.roi_Y2 = int(FD_config.window_view.ui.input_Y2.value())
			self.range_Ymin = int(FD_config.window_view.ui.input_Yrange_min.value())
			self.range_Ymax = int(FD_config.window_view.ui.input_Yrange_max.value())
			self.Log_path = FD_config.window_view.ui.log_filepath.text()
##########################################################################################################

##########################################################################################################
		def stop(self):
			with QtCore.QMutexLocker(self.mutex):
				self.stopped = True
##########################################################################################################

##########################################################################################################	       
		def __init__(self, parent=None):
			super(Rayonix_Trend_View_process, self).__init__(parent)
			self.stopped = False
			self.rep = 60 #[Hz]
			self.img_list = []
			self.run_list = []
			self.time_list = []
			self.time_array = np.array([])
			self.data_array = np.array([])
			### msg, Log initialization ###
			self.log_document = FD_config.window_view.ui.input_log.document
			self.highlighter = Highlighter(self.log_document())
			### instance ###
			self.__get_rayonix_data = GetRayonixData(self)
			self.mutex = QtCore.QMutex()
##########################################################################################################
		
##########################################################################################################
##########################################################################################################
##########################################################################################################
class Highlighter(QtGui.QSyntaxHighlighter):
##########################################################################################################
##########################################################################################################
##########################################################################################################

##########################################################################################################
### init ###
##########################################################################################################	
		def __init__(self,parent):			
			super(Highlighter, self).__init__(parent)
			self.warningFormat = QtGui.QTextCharFormat()
			self.warningFormat.setForeground(QtCore.Qt.blue)
			self.errorFormat = QtGui.QTextCharFormat()
			self.errorFormat.setForeground(QtCore.Qt.red)
##########################################################################################################
### init ###
##########################################################################################################	
		def highlightBlock(self,text):
			if text.startswith("[warning]"):
				self.setFormat(0,len(text),self.warningFormat)
			elif text.startswith("[error]"):
				self.setFormat(0,len(text),self.errorFormat)
##########################################################################################################	
##########################################################################################################
##########################################################################################################

##########################################################################################################
##########################################################################################################
##########################################################################################################
class TrendView_canvas(FigureCanvas):
##########################################################################################################
##########################################################################################################
##########################################################################################################

##########################################################################################################
### init ###
##########################################################################################################	
		def __init__(self):
			fig = Figure()
			fig.subplots_adjust(left=0.1, bottom=0.2, right=0.95, top=0.9, wspace=0, hspace=0)
			self.axes = fig.add_subplot(111) 
			fig.patch.set_facecolor((1, 0.3, 0))
			fig.patch.set_alpha(0.5)
			self.axes.tick_params(axis="x", labelbottom="on")
			self.axes.tick_params(axis="y", labelleft="on")
			self.axes.ticklabel_format(style='sci',axis='y',scilimits=(0,0))
			self.axes.ticklabel_format(style='sci',axis='x',scilimits=(0,0))
			self.axes.set_xlabel("time [s]")
			self.axes.set_ylabel("integrated count")
			self.axes.axis("tight")
			        	
			FigureCanvas.__init__(self, fig)
			FigureCanvas.setSizePolicy(self, QtWidgets.QSizePolicy.Expanding, QtWidgets.QSizePolicy.Expanding)
			FigureCanvas.updateGeometry(self)
##########################################################################################################	
##########################################################################################################
##########################################################################################################

