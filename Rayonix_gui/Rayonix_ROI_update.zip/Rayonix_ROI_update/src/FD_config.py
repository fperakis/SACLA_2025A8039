# -*- coding: utf-8 -*-

## window handle
window_view = None
window_log = None

## define
LOG_LEVEL = 20
HISTOGRAM_BINS = 10
LOG_MINIMUM = 0.001

## color settings
COLOR_LOG_DEBUG = "blue"
COLOR_LOG_INFO = "black"
COLOR_LOG_WARNING = "orange"
COLOR_LOG_ERROR = "red"
COLOR_PROFILE_X = "orange"
COLOR_PROFILE_Y = "red"
COLOR_PROFILE_LINE_X = "green"
COLOR_PROFILE_LINE_Y = "green"
COLOR_TEXT_VALID = "black"
COLOR_TEXT_INVALID = "red"

## log level
LOGLEVEL_DEBUG = 10
LOGLEVEL_INFO = 20
LOGLEVEL_WARNING = 30
LOGLEVEL_ERROR = 40
